
# SunShine LABs DocVerify g1 — Per-user uploads, Delete action, MOTD.txt

What’s new:
- **Per-user isolation**: uploads go to `uploads/<okta_sub>/...`
- **Delete action**: replace "Open" button with a **Delete** button (you can still click the filename to open details/downloads)
- **MOTD from file**: Home reads `motd.txt` so you can edit messaging without code changes
- **PDF-only**: extension + `%PDF-` magic header enforced
- **Recent**: shows Submitted (UTC) and SHA-256 (short); details show full hash

## Setup

1) Copy `okta_config.txt.example` → `okta_config.txt` and fill:
```
OKTA_ISSUER_BASE_URL=...
OKTA_CLIENT_ID=...
OKTA_CLIENT_SECRET=...
OKTA_REDIRECT_URI=   # optional
```

2) Optionally edit **motd.txt** to change the home message.

3) Run:
```bash
cd docverify_webui_okta_cfg2
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
# http://127.0.0.1:5000
```

Security notes (prototype):
- No CSRF protection on delete (can add later).
- In-memory storage (`DOCS`) is per-process.
