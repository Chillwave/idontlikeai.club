
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, send_file, flash
from authlib.integrations.flask_client import OAuth
from functools import wraps
from datetime import datetime
from pypdf import PdfReader
import os, uuid, hashlib

BASE_DIR = os.path.dirname(__file__)

def load_okta_config(path: str):
    cfg = {}
    if not os.path.exists(path):
        raise RuntimeError(f"Missing Okta config file: {path}. Please create it (see okta_config.txt.example).")
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"): continue
            if "=" not in line: continue
            k, v = line.split("=", 1)
            cfg[k.strip()] = v.strip()
    for key in ("OKTA_ISSUER_BASE_URL", "OKTA_CLIENT_ID", "OKTA_CLIENT_SECRET"):
        if key not in cfg or not cfg[key]:
            raise RuntimeError(f"Okta config missing required key: {key}")
    if "OKTA_REDIRECT_URI" not in cfg or not cfg["OKTA_REDIRECT_URI"]:
        cfg["OKTA_REDIRECT_URI"] = None
    return cfg

def read_motd(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return "Upload a PDF, finish processing to generate the encoded text file, then download it."

OKTA_CFG = load_okta_config(os.path.join(BASE_DIR, "okta_config.txt"))

app = Flask(__name__)
app.config.update({
    "SECRET_KEY": "change-me-dev-secret",
    **OKTA_CFG,
})

UPLOAD_ROOT = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_ROOT, exist_ok=True)

DOCS = {}

oauth = OAuth(app)
def _server_metadata_url():
    base = app.config["OKTA_ISSUER_BASE_URL"].rstrip("/")
    return f"{base}/.well-known/openid-configuration"

oauth.register(
    name="okta",
    client_id=app.config["OKTA_CLIENT_ID"],
    client_secret=app.config["OKTA_CLIENT_SECRET"],
    server_metadata_url=_server_metadata_url(),
    client_kwargs={"scope": "openid profile email"}
)

def current_user_id():
    return session.get("user_id")

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user_id():
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.template_filter("ts")
def format_ts(dt: datetime):
    if not dt: return ""
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC")

@app.route("/")
def root():
    if current_user_id():
        return redirect(url_for("home"))
    return redirect(url_for("login"))

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/login/okta")
def login_okta():
    redirect_uri = app.config.get("OKTA_REDIRECT_URI") or url_for("auth_callback", _external=True)
    return oauth.okta.authorize_redirect(redirect_uri=redirect_uri)

@app.route("/auth/callback")
def auth_callback():
    token = oauth.okta.authorize_access_token()
    userinfo = token.get("userinfo") or oauth.okta.parse_id_token(token)
    session["user_id"] = userinfo.get("sub") or userinfo.get("uid") or userinfo.get("email")
    session["user_email"] = userinfo.get("email")
    session["user_name"] = userinfo.get("name") or userinfo.get("preferred_username") or session["user_email"]
    flash(f"Welcome, {session.get('user_name', 'user')}!", "success")
    return redirect(url_for("home"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/home")
@login_required
def home():
    uid = current_user_id()
    user_docs = [d for d in DOCS.values() if d["owner_id"] == uid]
    recent = sorted(user_docs, key=lambda d: d["created_at"], reverse=True)[:5]
    motd = read_motd(os.path.join(BASE_DIR, "motd.txt"))
    return render_template("home.html", recent=recent, motd=motd)

def ensure_user_dir(uid: str) -> str:
    user_dir = os.path.join(UPLOAD_ROOT, uid)
    os.makedirs(user_dir, exist_ok=True)
    return user_dir

def is_pdf_upload(file_storage) -> bool:
    filename = (file_storage.filename or "").lower()
    if not filename.endswith(".pdf"):
        return False
    pos = file_storage.stream.tell()
    head = file_storage.stream.read(5)
    file_storage.stream.seek(pos)
    try:
        return head.startswith(b"%PDF-")
    except Exception:
        return False

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as rf:
        for chunk in iter(lambda: rf.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename.strip():
            flash("Choose a file to upload.", "error")
            return redirect(url_for("upload"))
        if not is_pdf_upload(f):
            flash("Only PDF documents are allowed.", "error")
            return redirect(url_for("upload"))
        uid = current_user_id()
        user_dir = ensure_user_dir(uid)
        doc_id = str(uuid.uuid4())[:8]
        safe_name = f.filename.replace("/", "_").replace("\\", "_")
        save_path = os.path.join(user_dir, f"{doc_id}__{safe_name}")
        f.save(save_path)
        file_hash = sha256_file(save_path)
        DOCS[doc_id] = {
            "id": doc_id,
            "filename": safe_name,
            "path": save_path,
            "owner_id": uid,
            "owner_email": session.get("user_email"),
            "status": "uploaded",
            "created_at": datetime.utcnow(),
            "hash": file_hash,
            "processed_path": None,
            "processed_kind": None,
        }
        return redirect(url_for("processing", doc_id=doc_id))
    return render_template("upload.html")

@app.route("/upload/<doc_id>/processing")
@login_required
def processing(doc_id):
    doc = DOCS.get(doc_id)
    if not doc or doc["owner_id"] != current_user_id():
        flash("Document not found.", "error")
        return redirect(url_for("home"))
    return render_template("processing.html", doc=doc)

@app.route("/upload/<doc_id>/finish", methods=["POST"])
@login_required
def finish(doc_id):
    doc = DOCS.get(doc_id)
    if not doc or doc["owner_id"] != current_user_id():
        flash("Document not found.", "error")
        return redirect(url_for("home"))
    text = ""
    try:
        reader = PdfReader(doc["path"])
        for page in reader.pages:
            text += page.extract_text() or ""
    except Exception as e:
        flash(f"Failed to read PDF text: {e}", "error")

    encoded = encode_text_java_style(text)

    processed_name = f"{doc['id']}__encoded.txt"
    processed_path = os.path.join(os.path.dirname(doc["path"]), processed_name)
    with open(processed_path, "w", encoding="utf-8") as wf:
        wf.write(encoded)

    doc["processed_path"] = processed_path
    doc["processed_kind"] = "txt"
    doc["status"] = "processed"
    flash("Processing complete.", "success")
    return redirect(url_for("doc_detail", doc_id=doc_id))

def encode_text_java_style(s: str) -> str:
    out = []
    for ch in s:
        if ch.isalnum():
            out.append(chr((ord(ch) % 65) + 68))
        else:
            out.append(ch)
    return "".join(out)

@app.route("/docs")
@login_required
def docs():
    uid = current_user_id()
    items = sorted([d for d in DOCS.values() if d["owner_id"] == uid], key=lambda d: d["created_at"], reverse=True)
    return render_template("docs.html", items=items)

@app.route("/docs/<doc_id>")
@login_required
def doc_detail(doc_id):
    doc = DOCS.get(doc_id)
    if not doc or doc["owner_id"] != current_user_id():
        flash("Document not found.", "error")
        return redirect(url_for("docs"))
    return render_template("doc_detail.html", doc=doc)

@app.route("/docs/<doc_id>/delete", methods=["POST"])
@login_required
def doc_delete(doc_id):
    doc = DOCS.get(doc_id)
    if not doc or doc["owner_id"] != current_user_id():
        flash("Document not found.", "error")
        return redirect(url_for("docs"))
    # Try to delete files
    for p in [doc.get("path"), doc.get("processed_path")]:
        if p and os.path.isfile(p):
            try:
                os.remove(p)
            except Exception:
                pass
    # Remove from in-memory DB
    DOCS.pop(doc_id, None)
    flash("Document deleted.", "success")
    return redirect(url_for("docs"))

@app.route("/download/<doc_id>")
@login_required
def download(doc_id):
    doc = DOCS.get(doc_id)
    if not doc or doc["owner_id"] != current_user_id():
        flash("Document not found.", "error")
        return redirect(url_for("docs"))
    directory = os.path.dirname(doc["path"])
    filename = os.path.basename(doc["path"])
    return send_from_directory(directory, filename, as_attachment=True)

@app.route("/download/<doc_id>/processed")
@login_required
def download_processed(doc_id):
    doc = DOCS.get(doc_id)
    if not doc or doc["owner_id"] != current_user_id() or not doc.get("processed_path"):
        flash("Processed file not available.", "error")
        return redirect(url_for("docs"))
    directory = os.path.dirname(doc["processed_path"])
    filename = os.path.basename(doc["processed_path"])
    return send_from_directory(directory, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
