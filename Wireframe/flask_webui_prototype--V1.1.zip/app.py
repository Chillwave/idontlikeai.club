
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, flash
import os, uuid, datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key'  # change for prod
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Toy in-memory "database"
DOCS = {}

def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('user'):
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper

@app.route('/')
def root():
    if session.get('user'):
        return redirect(url_for('home'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        # password is ignored in demo (prototype)
        if username:
            session['user'] = username
            flash('Welcome, {}!'.format(username), 'success')
            return redirect(url_for('home'))
        flash('Please enter a username.', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/home')
@login_required
def home():
    recent = sorted(DOCS.values(), key=lambda d: d['created_at'], reverse=True)[:5]
    return render_template('home.html', recent=recent)

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        file = request.files.get('file')
        if not file or file.filename.strip() == '':
            flash('Choose a file to upload.', 'error')
            return redirect(url_for('upload'))
        doc_id = str(uuid.uuid4())[:8]
        safe_name = file.filename.replace('/', '_').replace('\\','_')
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{doc_id}__{safe_name}")
        file.save(save_path)
        DOCS[doc_id] = {
            'id': doc_id,
            'filename': safe_name,
            'path': save_path,
            'status': 'uploaded',
            'created_at': datetime.datetime.utcnow(),
            'owner': session.get('user')
        }
        return redirect(url_for('processing', doc_id=doc_id))
    return render_template('upload.html')

@app.route('/upload/<doc_id>/processing')
@login_required
def processing(doc_id):
    doc = DOCS.get(doc_id)
    if not doc:
        flash('Document not found.', 'error')
        return redirect(url_for('home'))
    # Prototype: show a page with a button to "Finish processing"
    return render_template('processing.html', doc=doc)

@app.route('/upload/<doc_id>/finish', methods=['POST'])
@login_required
def finish(doc_id):
    doc = DOCS.get(doc_id)
    if not doc:
        flash('Document not found.', 'error')
        return redirect(url_for('home'))
    doc['status'] = 'processed'
    flash('Processing complete for {}.'.format(doc['filename']), 'success')
    return redirect(url_for('doc_detail', doc_id=doc_id))

@app.route('/docs')
@login_required
def docs():
    # List all docs for this user (demo—no strict ownership checks)
    items = sorted(DOCS.values(), key=lambda d: d['created_at'], reverse=True)
    return render_template('docs.html', items=items)

@app.route('/docs/<doc_id>')
@login_required
def doc_detail(doc_id):
    doc = DOCS.get(doc_id)
    if not doc:
        flash('Document not found.', 'error')
        return redirect(url_for('docs'))
    return render_template('doc_detail.html', doc=doc)

@app.route('/download/<doc_id>')
@login_required
def download(doc_id):
    doc = DOCS.get(doc_id)
    if not doc:
        flash('Document not found.', 'error')
        return redirect(url_for('docs'))
    return send_from_directory(app.config['UPLOAD_FOLDER'], os.path.basename(doc['path']), as_attachment=True)

# Simple "sidebar menu expand" is controlled in the template via CSS/JS

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
