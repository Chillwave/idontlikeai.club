
# Flask WebUI Prototype

A functional demonstration UI built with Flask: login, sidebar navigation, file upload flow, document list, and detail pages.

## Run it

```bash
cd flask_webui_prototype
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
# then open http://127.0.0.1:5000
```
### Demo flow
- **Login**: any username works.
- **Upload**: pick a file; you'll land on a Processing page.
- **Finish**: click the Finish Processing button to mark it as processed.
- **Documents**: see all uploads, open details, download originals.

> This is scaffolded for your real logic later: replace the finish step with actual processing.
